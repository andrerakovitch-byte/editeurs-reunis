<?php
/**
 * Title: La librairie
 * Slug: editeurs-reunis/librairie
 * Categories: editeurs-reunis
 * Inserter: no
 *
 * Toute la librairie, un rayon, un auteur, une langue ou une recherche : le titre, les rayons et les langues en
 * pilules, puis les livres en grand, sur toute la largeur. Pour un auteur, sa fiche (er/auteur-fiche : portrait,
 * dates, présentation, biographie, photos) remplace le titre, et ses livres viennent dessous.
 *
 * @package editeurs-reunis
 */

?>
<!-- wp:group {"tagName":"main","className":"er-librairie","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<main class="wp-block-group er-librairie" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:group {"align":"wide","className":"er-librairie-tete","layout":{"type":"default"}} -->
	<div class="wp-block-group alignwide er-librairie-tete">
		<!-- wp:woocommerce/breadcrumbs {"fontSize":"x-small"} /-->

<?php if ( is_tax( 'auteur' ) ) : ?>
		<!-- wp:er/auteur-fiche /-->
		<!-- wp:heading {"className":"er-auteur-livres"} -->
		<h2 class="wp-block-heading er-auteur-livres"><?php esc_html_e( 'Ses livres', 'editeurs-reunis' ); ?></h2>
		<!-- /wp:heading -->
<?php elseif ( is_search() ) : ?>
		<!-- wp:query-title {"type":"search"} /-->
<?php else : ?>
		<!-- wp:query-title {"type":"archive","showPrefix":false} /-->
<?php endif; ?>
<?php if ( function_exists( 'is_shop' ) && is_shop() && ! is_search() ) : ?>
		<!-- wp:paragraph {"className":"er-devise"} -->
		<p class="er-devise"><?php esc_html_e( 'Les Éditeurs réunis, librairie de référence depuis 1925', 'editeurs-reunis' ); ?></p>
		<!-- /wp:paragraph -->
<?php endif; ?>

<?php if ( ! is_tax( 'auteur' ) ) : // La présentation d'un auteur est dans sa fiche. ?>
		<!-- wp:term-description /-->
<?php endif; ?>
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"align":"wide","className":"er-filtres","layout":{"type":"default"}} -->
	<div class="wp-block-group alignwide er-filtres">
		<!-- wp:categories {"taxonomy":"langue","showPostCounts":false,"showEmpty":false,"className":"er-pilules er-pilules-langues"} /-->
	</div>
	<!-- /wp:group -->

	<!-- wp:woocommerce/store-notices /-->

	<!-- wp:group {"align":"wide","className":"er-tri","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide er-tri">
		<!-- wp:woocommerce/product-results-count /-->

		<!-- wp:woocommerce/catalog-sorting /-->
	</div>
	<!-- /wp:group -->

	<!-- wp:woocommerce/product-collection {"queryId":31,"query":{"woocommerceAttributes":[],"woocommerceStockStatus":["instock","outofstock","onbackorder"],"taxQuery":{},"isProductCollectionBlock":true,"perPage":20,"pages":0,"offset":0,"postType":"product","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":true},"tagName":"div","dimensions":{"widthType":"fill"},"displayLayout":{"type":"flex","columns":5,"shrinkColumns":true},"queryContextIncludes":["collection"],"align":"wide"} -->
	<div class="wp-block-woocommerce-product-collection alignwide">
		<?php echo er_fiche_livre(); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<!-- wp:query-pagination {"layout":{"type":"flex","justifyContent":"center"}} -->
			<!-- wp:query-pagination-previous {"label":"<?php echo er_attr( _x( 'Précédents', 'pagination des livres', 'editeurs-reunis' ) ); ?>"} /-->
			<!-- wp:query-pagination-numbers /-->
			<!-- wp:query-pagination-next {"label":"<?php echo er_attr( _x( 'Suivants', 'pagination des livres', 'editeurs-reunis' ) ); ?>"} /-->
		<!-- /wp:query-pagination -->

		<!-- wp:woocommerce/product-collection-no-results -->
			<!-- wp:paragraph -->
			<p><?php
			printf(
				wp_kses_post( /* translators: %s: l'adresse de la librairie. */ __( 'Aucun livre ne correspond. <a href="%s">Voir toute la librairie</a>, ou écrivez-nous : nous avons bien plus de livres en rayon qu’en ligne.', 'editeurs-reunis' ) ),
				er_lien( 'librairie/' ) // phpcs:ignore WordPress.Security.EscapeOutput
			);
			?></p>
			<!-- /wp:paragraph -->
		<!-- /wp:woocommerce/product-collection-no-results -->
	</div>
	<!-- /wp:woocommerce/product-collection -->
</main>
<!-- /wp:group -->
